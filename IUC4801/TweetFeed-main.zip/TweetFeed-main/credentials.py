from os import environ

consumer_key = environ['consumer_key']
consumer_secret_key = environ['consumer_secret_key']
access_token = environ['access_token']
access_token_secret = environ['access_token_secret']
